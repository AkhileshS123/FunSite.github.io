
public class FrequencyObj {
	private String word;
	private int freq;
	
	public FrequencyObj(String s, int n) {
		word = s;
		freq = n;
	}
	
	public String getWord() {
		return word;
	}
	
	public int getFreq() {
		return freq;
	}
}
